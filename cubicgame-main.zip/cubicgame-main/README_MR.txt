THIS IS NOT MY GAME!
 - it's Marcus'
 - It just looked fun, so i downloaded the original
 - u have to reinstall an older version of pillow to run this, so your newer programs may not work as well...

Here are the cmd's needed before running main:
pip uninstall pillow
pip install pillow==9.3.0
pip show pillow
pip install arcade
